﻿using QLDSV.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QLDSV
{
    public partial class frmMain : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private Form CheckExists(Type ftype)
        {
            foreach (Form f in this.MdiChildren)
                if (f.GetType() == ftype)
                    return f;
            return null;
        }

        private void btnLogin_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmLogin));
            if (frm != null) frm.Activate();
            else
            {
                frmLogin f = new frmLogin();
                f.Show();
            }
        }

        private void btnExit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Close();
        }

        private void btnLogout_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Program.currentRole = "";
            Program.currentUserName = "";
            Program.currentServer = "";
            Program.currentPass = "";
            Program.currentID = "";

            btnLogin.Enabled = true;
            btnLogout.Enabled = false;

            userID.Text = "UerID";
            userName.Text = "Name";
            userRole.Text = "Role";

            foreach (Form form in this.MdiChildren)
            {
                form.Close();
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            btnLogout.Enabled = false;
            ribbonManaGroup.Enabled = false;
        }

        private void btnSubject_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmSubject));
            if (frm != null) frm.Activate();
            else
            {
                frmSubject f = new frmSubject();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void btnCLass_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmClass));
            if (frm != null) frm.Activate();
            else
            {
                frmClass f = new frmClass();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void btnTeacher_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmTeacher));
            if (frm != null) frm.Activate();
            else
            {
                frmTeacher f = new frmTeacher();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void btnStudent_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmStudent));
            if (frm != null) frm.Activate();
            else
            {
                frmStudent f = new frmStudent();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void btnPoint_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmMenu));
            if (frm != null) frm.Activate();
            else
            {
                frmMenu f = new frmMenu();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void btnCreate_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.CheckExists(typeof(frmSignUp));
            if (frm != null) frm.Activate();
            else
            {
                frmSignUp f = new frmSignUp();
                f.MdiParent = this;
                f.Show();
            }
        }
    }
}
